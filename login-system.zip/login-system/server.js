const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const JWT_SECRET = 'change-this-to-a-long-random-secret-in-production';
const DB_PATH = path.join(__dirname, 'data', 'users.json');

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: true, credentials: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ── DB helpers (JSON file as database) ─────────────────────────────────────
function readUsers() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    return [];
  }
}

function writeUsers(users) {
  fs.writeFileSync(DB_PATH, JSON.stringify(users, null, 2));
}

function findUser(email) {
  return readUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
}

// ── Auth middleware ─────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  const token = req.cookies.token || (req.headers.authorization || '').replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Not authenticated' });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.clearCookie('token');
    res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
}

// ── Routes ──────────────────────────────────────────────────────────────────

// POST /api/register
app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password)
    return res.status(400).json({ error: 'All fields are required.' });

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: 'Enter a valid email address.' });

  if (password.length < 8)
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  if (findUser(email))
    return res.status(409).json({ error: 'An account with that email already exists.' });

  const users = readUsers();
  const hashed = await bcrypt.hash(password, 12);
  const user = {
    id: Date.now().toString(),
    name: name.trim(),
    email: email.toLowerCase().trim(),
    password: hashed,
    createdAt: new Date().toISOString()
  };
  users.push(user);
  writeUsers(users);

  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
  res.status(201).json({ message: 'Account created.', user: { id: user.id, name: user.name, email: user.email } });
});

// POST /api/login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ error: 'Email and password are required.' });

  const user = findUser(email);
  if (!user) return res.status(401).json({ error: 'No account found with that email.' });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ error: 'Incorrect password.' });

  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
  res.json({ message: 'Logged in.', user: { id: user.id, name: user.name, email: user.email } });
});

// POST /api/logout
app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out.' });
});

// GET /api/me  (protected)
app.get('/api/me', requireAuth, (req, res) => {
  const user = findUser(req.user.email);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: { id: user.id, name: user.name, email: user.email, createdAt: user.createdAt } });
});

// PATCH /api/me  (protected) — update name
app.patch('/api/me', requireAuth, (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Name cannot be empty.' });

  const users = readUsers();
  const idx = users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found.' });

  users[idx].name = name.trim();
  writeUsers(users);

  const token = jwt.sign({ id: users[idx].id, email: users[idx].email, name: users[idx].name }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
  res.json({ user: { id: users[idx].id, name: users[idx].name, email: users[idx].email } });
});

// DELETE /api/me  (protected)
app.delete('/api/me', requireAuth, async (req, res) => {
  const { password } = req.body;
  const user = findUser(req.user.email);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ error: 'Incorrect password.' });

  const users = readUsers().filter(u => u.id !== user.id);
  writeUsers(users);
  res.clearCookie('token');
  res.json({ message: 'Account deleted.' });
});

// ── YouTube RSS proxy ─────────────────────────────────────────────────────────
const https = require('https');

app.get('/api/yt-feed', (req, res) => {
  const url = 'https://www.youtube.com/feeds/videos.xml?channel_id=UCJVrkR0a3mcs2WwYV9oGkLg';
  https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (ytRes) => {
    res.setHeader('Content-Type', 'application/xml');
    ytRes.pipe(res);
  }).on('error', (e) => {
    res.status(502).json({ error: 'Failed to fetch YouTube feed', detail: e.message });
  });
});

// ── Start ───────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n  Login system running at http://localhost:${PORT}`);
  console.log(`  Channel page: http://localhost:${PORT}/channel.html\n`);
});
