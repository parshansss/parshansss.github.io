# Login System

A complete, production-ready login system built with Node.js, Express, and a JSON file database.

## Features

- **Register** — name, email, password with strength meter
- **Login** — email + password, JWT stored in HttpOnly cookie
- **Dashboard** — view account details, edit name
- **Auto-login** — session persists across page refreshes (7-day JWT)
- **Delete account** — password-confirmed, permanent
- **Security** — bcrypt password hashing (cost 12), HttpOnly JWT cookie, input validation

## Tech Stack

| Layer    | Tech                       |
|----------|----------------------------|
| Server   | Node.js + Express          |
| Auth     | JWT (jsonwebtoken)         |
| Passwords| bcryptjs (12 rounds)       |
| Database | JSON file (`data/users.json`) |
| Frontend | Vanilla HTML/CSS/JS        |

## Setup

```bash
# 1. Install dependencies (already done if you unzip this)
npm install

# 2. Start the server
node server.js

# 3. Open in browser
open http://localhost:3000
```

## Project Structure

```
login-system/
├── server.js          # Express API server
├── public/
│   └── index.html     # Frontend (login, register, dashboard)
├── data/
│   └── users.json     # JSON database (auto-populated)
└── package.json
```

## API Endpoints

| Method | Path       | Auth? | Description           |
|--------|------------|-------|-----------------------|
| POST   | /api/register | —  | Create account        |
| POST   | /api/login    | —  | Sign in               |
| POST   | /api/logout   | —  | Clear session cookie  |
| GET    | /api/me       | ✓  | Get current user      |
| PATCH  | /api/me       | ✓  | Update name           |
| DELETE | /api/me       | ✓  | Delete account        |

## Production Notes

Before deploying, change these in `server.js`:

1. **JWT Secret** — replace `'change-this-to-a-long-random-secret-in-production'` with a long random string (use `openssl rand -hex 64`)
2. **HTTPS** — add `secure: true` to the cookie options
3. **Database** — swap the JSON file for a real database (PostgreSQL, MongoDB, etc.)
4. **Rate limiting** — add `express-rate-limit` to prevent brute-force attacks
